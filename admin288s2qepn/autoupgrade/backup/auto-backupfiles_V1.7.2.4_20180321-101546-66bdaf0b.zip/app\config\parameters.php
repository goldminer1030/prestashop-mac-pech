<?php return array (
  'parameters' => 
  array (
    'database_host' => '127.0.0.1',
    'database_port' => '',
    'database_name' => 'prestashop_fishing',
    'database_user' => 'root',
    'database_password' => '',
    'database_prefix' => 'ps_',
    'database_engine' => 'InnoDB',
    'mailer_transport' => 'smtp',
    'mailer_host' => '127.0.0.1',
    'mailer_user' => NULL,
    'mailer_password' => NULL,
    'secret' => 'KQRNYaTgE5DE3kKYtCSITvuVekPsv5EYdxBkVPkky0PBCKpVYdNFuTIM',
    'ps_caching' => 'CacheMemcache',
    'ps_cache_enable' => false,
    'ps_creation_date' => '2018-02-19',
    'locale' => 'en-US',
    'cookie_key' => 'UB1AmzUOAnJNpbEIAmN7o52T1dbT5xhgTcG5u0Rwtsd6y8oTaFu3cEJm',
    'cookie_iv' => 'aSejrKTX',
    'new_cookie_key' => 'def000009f310cc5cb9ce919d5af0d58e36f06fc00048737c50d34a79852c4f7b9f6140ed9ed18dbeeee28f109f510b8616fd8bd985f893b24573a39e89773a5b2cc3040',
  ),
);